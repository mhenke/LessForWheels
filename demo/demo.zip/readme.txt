1) Follow the instructions for installing the LESS For Wheels plugin.
2) Copy these files into your web root
3) load /less/show and you should see the style applied from the demo.css created from the demo.less